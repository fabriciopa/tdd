/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacoes;

/**
 *
 * @author fabricioaraujo
 */
public class Operacoes {
    
    public Boolean eNumPar (int n){
        return n%2==0;
    }
    
    public Boolean eNumImpar (int n){
        return n%2!=0;
    }
    
    public int soma (int n1, int n2){
        return n1 + n2;
    }
    
    public int multiplicacao (int n1, int n2){
        return n1 * n2;
    }
    
    public int divisao (int n1, int n2){
        return (n2>0?n1/n2:0);
    }
    
    public int areaQuadrado (int lado){
        return lado * lado;
    }
}
