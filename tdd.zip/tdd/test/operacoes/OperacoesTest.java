/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacoes;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author fabricioaraujo
 */
public class OperacoesTest {
    
    private Operacoes opr;
    
    public OperacoesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        opr = new Operacoes();
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of eNumPar method, of class Operacoes.
     */
    @Test
    public void testENumPar() {
        assertEquals(true, opr.eNumPar(2));
        assertFalse(opr.eNumPar(3));
        assertFalse(opr.eNumPar(-345));
        assertEquals(true, opr.eNumPar(0));
    }

    /**
     * Test of eNumImpar method, of class Operacoes.
     */
    @Test
    public void testENumImpar() {
        assertFalse(opr.eNumImpar(2));
        assertEquals(true, opr.eNumImpar(3));
        assertEquals(true, opr.eNumImpar(-345));
        assertFalse(opr.eNumImpar(0));
    }

    /**
     * Test of soma method, of class Operacoes.
     */
    @Test
    public void testSoma() {
        assertNotEquals(5, opr.soma(0, 0));
        assertEquals(5, opr.soma(2, 3));
        assertEquals(-10, opr.soma(-5, -5));
        assertNotEquals(32, opr.soma(10, -22));
    }

    /**
     * Test of multiplicacao method, of class Operacoes.
     */
    @Test
    public void testMultiplicacao() {
        assertNotEquals(5, opr.multiplicacao(0, 0));
        assertEquals(6, opr.multiplicacao(2, 3));
        assertNotEquals(-25, opr.multiplicacao(-5, -5));
        assertEquals(-220, opr.multiplicacao(10, -22));
    }

    /**
     * Test of divisao method, of class Operacoes.
     */
    @Test
    public void testDivisao() {
        assertNotEquals(1, opr.divisao(5, 0));
        assertEquals(2, opr.divisao(6, 3));
        assertNotEquals(1, opr.divisao(-5, -5));
        assertNotEquals(6, opr.divisao(30, -5));
    }

    /**
     * Test of areaQuadrado method, of class Operacoes.
     */
    @Test
    public void testAreaQuadrado() {
        assertEquals(25, opr.areaQuadrado(5));
        assertNotEquals(25, opr.areaQuadrado(3));
        assertNotEquals(-16, opr.areaQuadrado(-4));
        assertEquals(16, opr.areaQuadrado(4));
    }
    
}
